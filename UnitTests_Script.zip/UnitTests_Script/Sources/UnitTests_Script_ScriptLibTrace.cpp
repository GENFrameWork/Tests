/**-------------------------------------------------------------------------------------------------------------------
* @file       UnitTests_Script_ScriptLibTrace.cpp
* @brief      Unit tests for SCRIPT_LIB_TRACE
* @ingroup    TESTS
* --------------------------------------------------------------------------------------------------------------------*/
#include "GEN_Defines.h"
#include "UnitTests_Script_ScriptLibTrace.h"
#include "UnitTests_Script_TestHelpers.h"
#include "Script_Lib_Trace.h"
#include "GEN_Control.h"

#ifdef GOOGLETEST_ACTIVE
UNITTESTS_SCRIPT_LIBRARY_REGISTRATION_TEST(TEST_SCRIPTLIBTRACE, UNITTESTS_SCRIPTLIBTRACE_CLASSNAME, SCRIPT_LIB_TRACE, SCRIPT_LIB_NAME_TRACE, __L("TracePrintColor"))
#endif
