/**-------------------------------------------------------------------------------------------------------------------
* @file       UnitTests_Script_ScriptLanguageLua.cpp
* @brief      Unit tests for the Lua interpreter
* @ingroup    TESTS
* --------------------------------------------------------------------------------------------------------------------*/
#include "GEN_Defines.h"
#include "UnitTests_Script_ScriptLanguageLua.h"
#include "UnitTests_Script_TestHelpers.h"

#ifdef SCRIPT_LUA_ACTIVE
#include "Script_Language_Lua.h"
#endif

#include "GEN_Control.h"

#if defined(GOOGLETEST_ACTIVE) && defined(SCRIPT_LUA_ACTIVE)
namespace TEST_SCRIPTLANGUAGELUA
{

TEST(UNITTESTS_SCRIPTLANGUAGELUA_CLASSNAME, ExecutesNumericResult)
{
  SCRIPT_LNG_LUA script;
  int returnvalue = 0;

  (*script.GetScript()) = __L("return 42");
  EXPECT_EQ(script.Run(&returnvalue), SCRIPT_ERRORCODE_NONE);
  EXPECT_EQ(returnvalue, 42);
}


TEST(UNITTESTS_SCRIPTLANGUAGELUA_CLASSNAME, ReportsSyntaxError)
{
  SCRIPT_LNG_LUA script;

  (*script.GetScript()) = __L("function main(");
  EXPECT_NE(script.Run(), SCRIPT_ERRORCODE_NONE);
}

}
#endif
