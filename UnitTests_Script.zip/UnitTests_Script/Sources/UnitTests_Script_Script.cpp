/**-------------------------------------------------------------------------------------------------------------------
* @file       UnitTests_Script_Script.cpp
* @brief      Unit tests for SCRIPT
* @ingroup    TESTS
* --------------------------------------------------------------------------------------------------------------------*/
#include "GEN_Defines.h"
#include "UnitTests_Script_Script.h"
#include "UnitTests_Script_TestHelpers.h"
#include "Script_Language_G.h"
#include "GEN_Control.h"

#ifdef GOOGLETEST_ACTIVE
namespace TEST_SCRIPT
{

TEST(UNITTESTS_SCRIPT_CLASSNAME, DetectsEnabledExtensions)
{
  EXPECT_EQ(SCRIPT::GetTypeByExtension(__L("sample.g")), SCRIPT_TYPE_G);
  EXPECT_EQ(SCRIPT::GetTypeByExtension(__L("sample.G")), SCRIPT_TYPE_G);
  EXPECT_EQ(SCRIPT::GetTypeByExtension(__L("sample.unknown")), SCRIPT_TYPE_UNKNOWN);
  EXPECT_EQ(SCRIPT::GetTypeByExtension(NULL), SCRIPT_TYPE_UNKNOWN);
}


TEST(UNITTESTS_SCRIPT_CLASSNAME, CapabilitiesCanBeRestrictedAndRestored)
{
  SCRIPT script;

  EXPECT_TRUE(script.SetCapabilities(SCRIPT_CAPABILITY_NONE));
  EXPECT_FALSE(script.IsCapabilityEnabled(SCRIPT_CAPABILITY_PROCESS));
  EXPECT_TRUE(script.EnableCapabilities(SCRIPT_CAPABILITY_PROCESS));
  EXPECT_TRUE(script.IsCapabilityEnabled(SCRIPT_CAPABILITY_PROCESS));
  EXPECT_TRUE(script.DisableCapabilities(SCRIPT_CAPABILITY_PROCESS));
  EXPECT_FALSE(script.SetCapabilities(0x80000000));
}


TEST(UNITTESTS_SCRIPT_CLASSNAME, RejectsUnconfinedScriptNames)
{
  XPATH path;

  EXPECT_FALSE(SCRIPT::ResolvePathInScriptsRoot(__L("../outside.g"), path));
  EXPECT_FALSE(SCRIPT::ResolvePathInScriptsRoot(__L("C:/outside.g"), path));
  EXPECT_FALSE(SCRIPT::ResolvePathInScriptsRoot(__L("folder//test.g"), path));
  EXPECT_TRUE(SCRIPT::ResolvePathInScriptsRoot(__L("folder/test.g"), path));
}


TEST(UNITTESTS_SCRIPT_CLASSNAME, TrimsConfiguredNames)
{
  XSTRING name(__L("  test.g\t"));

  EXPECT_TRUE(SCRIPT::EliminateExtraChars(&name));
  EXPECT_EQ(name.Compare(__L("test.g")), 0);
  EXPECT_FALSE(SCRIPT::EliminateExtraChars(NULL));
}

}
#endif
