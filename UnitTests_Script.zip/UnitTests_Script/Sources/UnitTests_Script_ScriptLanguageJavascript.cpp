/**-------------------------------------------------------------------------------------------------------------------
* @file       UnitTests_Script_ScriptLanguageJavascript.cpp
* @brief      Unit tests for the JavaScript interpreter
* @ingroup    TESTS
* --------------------------------------------------------------------------------------------------------------------*/
#include "GEN_Defines.h"
#include "UnitTests_Script_ScriptLanguageJavascript.h"
#include "UnitTests_Script_TestHelpers.h"

#ifdef SCRIPT_JAVASCRIPT_ACTIVE
#include "Script_Language_Javascript.h"
#endif

#include "GEN_Control.h"

#if defined(GOOGLETEST_ACTIVE) && defined(SCRIPT_JAVASCRIPT_ACTIVE)
namespace TEST_SCRIPTLANGUAGEJAVASCRIPT
{

TEST(UNITTESTS_SCRIPTLANGUAGEJAVASCRIPT_CLASSNAME, ExecutesNumericResult)
{
  SCRIPT_LNG_JAVASCRIPT script;
  int returnvalue = 0;

  (*script.GetScript()) = __L("42");
  EXPECT_EQ(script.Run(&returnvalue), SCRIPT_ERRORCODE_NONE);
  EXPECT_EQ(returnvalue, 42);
}


TEST(UNITTESTS_SCRIPTLANGUAGEJAVASCRIPT_CLASSNAME, RejectsNonNumericResult)
{
  SCRIPT_LNG_JAVASCRIPT script;
  int returnvalue = 0;

  (*script.GetScript()) = __L("'not numeric'");
  EXPECT_NE(script.Run(&returnvalue), SCRIPT_ERRORCODE_NONE);
}

}
#endif
