function main()
{
  return 42;
}
