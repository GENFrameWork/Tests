function main()
  return 42
end

return main()
